package app.newyear.snowfall

import android.app.KeyguardManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.WindowManager

/** Живые обои: ночные горы (или своё фото) + снегопад, сугробы и гирлянда. */
class SnowWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SnowEngine()

    inner class SnowEngine : Engine(), SensorEventListener {
        private val ctx: Context = this@SnowWallpaperService
        private val scene = SnowScene(ctx, true)
        private val handler = Handler(Looper.getMainLooper())
        private val choreo = Choreographer.getInstance()
        private val kg = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        private var visible = false
        private var sensorOn = false
        private var last = 0L
        private var locked = false
        private var lockTick = 0

        private val frame = Choreographer.FrameCallback { tick() }
        private val poll = Runnable { tick() }

        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            handler.post {
                scene.reload()
                updateSensor()
                if (visible) schedule()
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            Prefs.sp(ctx).registerOnSharedPreferenceChangeListener(prefsListener)
        }

        override fun onDestroy() {
            Prefs.sp(ctx).unregisterOnSharedPreferenceChangeListener(prefsListener)
            stopLoop()
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scene.resize(width, height)
            if (visible) schedule()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            stopLoop()
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                scene.reload()
                updateSensor()
                schedule()
            } else {
                stopLoop()
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            scene.onTouch(event.actionMasked, event.x, event.y)
            super.onTouchEvent(event)
        }

        // ---------------------------------------------------------------- цикл

        private fun stopLoop() {
            visible = false
            handler.removeCallbacks(poll)
            choreo.removeFrameCallback(frame)
            updateSensor()
        }

        private fun schedule() {
            handler.removeCallbacks(poll)
            choreo.removeFrameCallback(frame)
            last = 0L
            tick()
        }

        private fun snowWanted(): Boolean {
            if (isPreview) return true
            val p = scene.params
            if (!p.enabled || p.mode == Prefs.MODE_APPS) return false
            // если поверх всего уже идёт оверлей — на разблокированном экране обои не дублируют снег
            if (OverlayService.running) {
                if (lockTick++ % 20 == 0) locked = kg.isKeyguardLocked
                if (!locked) return false
            }
            return true
        }

        private fun tick() {
            if (!visible) return
            val snow = snowWanted()
            scene.snowOn = snow
            val now = System.nanoTime()
            val dt = if (last == 0L) 0.016f else (now - last) / 1_000_000_000f
            last = now
            scene.update(dt)
            drawFrame()
            if (snow) {
                choreo.postFrameCallback(frame)
            } else {
                last = 0L
                locked = kg.isKeyguardLocked
                handler.postDelayed(poll, 1000)
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (c != null) scene.draw(c)
            } catch (e: Exception) {
                // поверхность ещё не готова
            } finally {
                if (c != null) {
                    try {
                        holder.unlockCanvasAndPost(c)
                    } catch (e: Exception) {
                    }
                }
            }
        }

        // ---------------------------------------------------------------- наклон

        private fun updateSensor() {
            val want = visible && scene.params.tilt && scene.params.enabled
            if (want && !sensorOn) {
                val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (s != null) {
                    sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
                    sensorOn = true
                }
            } else if (!want && sensorOn) {
                sm.unregisterListener(this)
                sensorOn = false
                scene.tilt = 0f
            }
        }

        override fun onSensorChanged(e: SensorEvent) {
            val v = e.values
            @Suppress("DEPRECATION")
            val rot = wm.defaultDisplay.rotation
            val g = when (rot) {
                Surface.ROTATION_90 -> v[1]
                Surface.ROTATION_180 -> v[0]
                Surface.ROTATION_270 -> -v[1]
                else -> -v[0]
            } / 9.81f
            scene.tilt += (g.coerceIn(-1f, 1f) - scene.tilt) * 0.08f
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
