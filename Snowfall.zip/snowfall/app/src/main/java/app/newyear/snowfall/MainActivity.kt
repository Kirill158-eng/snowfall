package app.newyear.snowfall

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val BG = Color.parseColor("#070C1F")
    private val CARD = Color.parseColor("#111A38")
    private val LINE = Color.parseColor("#26FFFFFF")
    private val ACCENT = Color.parseColor("#7CC4FF")
    private val SUB = Color.parseColor("#9FB0E0")
    private val GOOD = Color.parseColor("#6EE7A8")

    private val REQ_PICK = 11
    private val REQ_NOTIF = 12

    private lateinit var sp: SharedPreferences
    private lateinit var preview: SnowView
    private lateinit var masterSwitch: Switch
    private lateinit var overlayRow: Row
    private lateinit var wallpaperRow: Row
    private val modeCards = ArrayList<LinearLayout>()
    private val bgButtons = ArrayList<Button>()

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        preview.reload()
    }

    private class Row(val root: LinearLayout, val status: TextView, val button: Button)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(40))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // превью
        val frame = FrameLayout(this)
        preview = SnowView(this, true)
        frame.addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(230)))
        val title = TextView(this)
        title.text = "С Новым годом! ❄"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setShadowLayer(10f, 0f, 2f, Color.BLACK)
        title.setPadding(dp(16), 0, dp(16), dp(12))
        title.isClickable = false
        frame.addView(title, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(22).toFloat())
            }
        }
        frame.clipToOutline = true
        col.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(230)))
        col.add(hint("Проведи пальцем по превью — снег разлетится, а сугроб можно «сметать»."), 8)

        // главный выключатель
        val master = card()
        masterSwitch = Switch(this)
        masterSwitch.isChecked = sp.getBoolean(Prefs.K_ENABLED, true)
        masterSwitch.setOnCheckedChangeListener { _, checked ->
            sp.edit().putBoolean(Prefs.K_ENABLED, checked).apply()
            OverlayService.sync(this)
            updateUi()
        }
        master.addView(rowOf(label("Снегопад включён", "Главный выключатель для обоев и приложений"), masterSwitch))
        col.add(master, 16)

        // режим
        col.add(section("Где идёт снег"), 20)
        addMode(col, Prefs.MODE_WALLPAPER, "🖼  Только на обоях", "Рабочий стол и экран блокировки")
        addMode(col, Prefs.MODE_APPS, "📱  Только в приложениях", "Снег поверх любых приложений")
        addMode(col, Prefs.MODE_BOTH, "✨  И там, и там", "Максимум новогоднего настроения")

        // разрешения
        overlayRow = permRow("Поверх других приложений", "Разрешить") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        wallpaperRow = permRow("Живые обои «Снегопад»", "Установить") { openWallpaperPicker() }
        col.add(overlayRow.root, 12)
        col.add(wallpaperRow.root, 8)

        // настройки снега
        col.add(section("Снегопад"), 24)
        val snow = card()
        snow.add(slider("Количество", Prefs.K_DENSITY, 55) { "$it%" }, 0)
        snow.add(slider("Скорость", Prefs.K_SPEED, 50) { "$it%" }, 14)
        snow.add(slider("Размер хлопьев", Prefs.K_SIZE, 50) { "$it%" }, 14)
        snow.add(slider("Ветер", Prefs.K_WIND, 40) { "$it%" }, 14)
        col.add(snow, 8)

        col.add(section("Сугробы и эффекты"), 24)
        val fx = card()
        fx.add(switchRow("Сугробы", "Снег оседает внизу экрана", Prefs.K_DRIFTS, true), 0)
        fx.add(slider("Таяние сугробов", Prefs.K_MELT, 30) { if (it == 0) "не тают" else "$it%" }, 14)
        fx.add(switchRow("Снежинки-кристаллы", "Крупные резные снежинки", Prefs.K_CRYSTALS, true), 14)
        fx.add(switchRow("Гирлянда", "Мерцающие огоньки сверху", Prefs.K_GARLAND, true), 14)
        fx.add(switchRow("Ветер от наклона", "Снег сносит, когда наклоняешь телефон", Prefs.K_TILT, true), 14)
        fx.add(switchRow("Сметать касанием", "На живых обоях: проведи по снегу пальцем", Prefs.K_SWEEP, true), 14)
        col.add(fx, 8)

        // фон обоев
        col.add(section("Фон живых обоев"), 24)
        val bg = card()
        val bgRow = LinearLayout(this)
        bgRow.orientation = LinearLayout.HORIZONTAL
        val b1 = smallButton("Ночные горы") {
            sp.edit().putInt(Prefs.K_BG, 0).apply()
            updateUi()
        }
        val b2 = smallButton("Своё фото…") { pickImage() }
        bgButtons.add(b1)
        bgButtons.add(b2)
        bgRow.addView(b1, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val gap = View(this)
        bgRow.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        bgRow.addView(b2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bg.addView(bgRow)
        col.add(bg, 8)

        col.add(
            hint(
                "Если снег пропадает через время (Xiaomi, Huawei, Samsung, OnePlus), открой настройки " +
                    "приложения и разреши автозапуск, а ограничение батареи поставь «Без ограничений»."
            ), 20
        )

        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        sp.registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onResume() {
        super.onResume()
        preview.start()
        updateUi()
        OverlayService.sync(this)
    }

    override fun onPause() {
        preview.stop()
        super.onPause()
    }

    override fun onDestroy() {
        sp.unregisterOnSharedPreferenceChangeListener(prefsListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- состояние

    private fun updateUi() {
        val mode = sp.getInt(Prefs.K_MODE, Prefs.MODE_BOTH)
        for (i in modeCards.indices) {
            val sel = i == mode
            modeCards[i].background = roundBg(if (sel) Color.parseColor("#1B2B5C") else CARD, 18, if (sel) ACCENT else LINE, if (sel) 2 else 1)
        }

        val canOverlay = Settings.canDrawOverlays(this)
        overlayRow.root.visibility = if (mode != Prefs.MODE_WALLPAPER) View.VISIBLE else View.GONE
        overlayRow.status.text = if (canOverlay) "✓ Разрешение выдано" else "Нужно разрешение, чтобы снег шёл поверх приложений"
        overlayRow.status.setTextColor(if (canOverlay) GOOD else SUB)
        overlayRow.button.visibility = if (canOverlay) View.GONE else View.VISIBLE

        val wpActive = wallpaperActive()
        wallpaperRow.root.visibility = if (mode != Prefs.MODE_APPS) View.VISIBLE else View.GONE
        wallpaperRow.status.text = if (wpActive) "✓ Живые обои установлены" else "Установи живые обои, чтобы снег шёл на рабочем столе"
        wallpaperRow.status.setTextColor(if (wpActive) GOOD else SUB)
        wallpaperRow.button.visibility = if (wpActive) View.GONE else View.VISIBLE

        val custom = sp.getInt(Prefs.K_BG, 0) == 1
        for (i in bgButtons.indices) {
            val sel = (i == 1) == custom
            bgButtons[i].background = roundBg(if (sel) ACCENT else Color.parseColor("#1B2B5C"), 12)
            bgButtons[i].setTextColor(if (sel) Color.parseColor("#06102E") else Color.WHITE)
        }
    }

    private fun wallpaperActive(): Boolean {
        val info = WallpaperManager.getInstance(this).wallpaperInfo
        return info != null && info.packageName == packageName
    }

    private fun openWallpaperPicker() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, SnowWallpaperService::class.java)
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Открой «Обои» в настройках и выбери «Снегопад»", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------------------- свой фон

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть выбор фото", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            importBackground(uri)
        }
    }

    private fun importBackground(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 3000) sample *= 2
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) {
                    runOnUiThread { Toast.makeText(this, "Не удалось прочитать фото", Toast.LENGTH_SHORT).show() }
                    return@Thread
                }
                File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                bmp.recycle()
                runOnUiThread {
                    sp.edit()
                        .putInt(Prefs.K_BG, 1)
                        .putInt(Prefs.K_BG_REV, sp.getInt(Prefs.K_BG_REV, 0) + 1)
                        .apply()
                    updateUi()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    // ---------------------------------------------------------------- построение UI

    private fun LinearLayout.add(v: View, top: Int) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(top)
        addView(v, lp)
    }

    private fun roundBg(fill: Int, radius: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(strokeDp), stroke)
        return d
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(CARD, 18, LINE)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun section(text: String): TextView {
        val t = TextView(this)
        t.text = text.uppercase()
        t.setTextColor(ACCENT)
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.12f
        t.setPadding(dp(4), 0, 0, 0)
        return t
    }

    private fun hint(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(SUB)
        t.textSize = 12.5f
        t.setPadding(dp(4), 0, dp(4), 0)
        return t
    }

    private fun label(title: String, sub: String?): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        box.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(SUB)
            s.textSize = 12.5f
            box.addView(s)
        }
        return box
    }

    private fun rowOf(left: View, right: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(right, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return r
    }

    private fun addMode(parent: LinearLayout, mode: Int, title: String, sub: String) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(label(title, sub))
        c.setOnClickListener {
            sp.edit().putInt(Prefs.K_MODE, mode).apply()
            OverlayService.sync(this)
            updateUi()
        }
        modeCards.add(c)
        parent.add(c, 8)
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        b.textSize = 14f
        b.setTextColor(Color.WHITE)
        b.background = roundBg(Color.parseColor("#1B2B5C"), 12)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun permRow(title: String, buttonText: String, onClick: () -> Unit): Row {
        val c = card()
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        val s = TextView(this)
        s.setTextColor(SUB)
        s.textSize = 12.5f
        val b = smallButton(buttonText, onClick)
        b.background = roundBg(ACCENT, 12)
        b.setTextColor(Color.parseColor("#06102E"))
        b.typeface = Typeface.DEFAULT_BOLD
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(t)
        left.addView(s)
        c.addView(rowOf(left, b))
        return Row(c, s, b)
    }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean): View {
        val sw = Switch(this)
        sw.isChecked = sp.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply() }
        return rowOf(label(title, sub), sw)
    }

    private fun slider(title: String, key: String, def: Int, fmt: (Int) -> String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val value = TextView(this)
        value.setTextColor(ACCENT)
        value.textSize = 14f
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        box.addView(rowOf(t, value))
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = sp.getInt(key, def)
        sb.progressTintList = ColorStateList.valueOf(ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(ACCENT)
        value.text = fmt(sb.progress)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                value.text = fmt(p)
                if (fromUser) sp.edit().putInt(key, p).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(sb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return box
    }
}
