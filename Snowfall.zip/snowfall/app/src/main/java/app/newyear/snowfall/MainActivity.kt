package app.newyear.snowfall

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val BG = Color.parseColor("#070C1F")
    private val CARD = Color.parseColor("#111A38")
    private val LINE = Color.parseColor("#26FFFFFF")
    private val ACCENT = Color.parseColor("#7CC4FF")
    private val SUB = Color.parseColor("#9FB0E0")
    private val GOOD = Color.parseColor("#6EE7A8")
    private val CHIP = Color.parseColor("#1B2B5C")
    private val INK = Color.parseColor("#06102E")

    private val REQ_PICK = 11
    private val REQ_NOTIF = 12

    private lateinit var sp: SharedPreferences
    private lateinit var preview: SnowView
    private lateinit var masterSwitch: Switch
    private lateinit var overlayRow: Row
    private lateinit var wallpaperRow: Row
    private val modeCards = ArrayList<LinearLayout>()
    private val refreshers = ArrayList<() -> Unit>()

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        preview.reload()
    }

    private class Row(val root: LinearLayout, val status: TextView, val button: Button)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(40))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // превью
        val frame = FrameLayout(this)
        preview = SnowView(this, true)
        frame.addView(preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(260)))
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(22).toFloat())
            }
        }
        frame.clipToOutline = true
        col.addView(frame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))
        col.add(hint("Проведи пальцем по превью: снег разлетится, а сугроб можно «сметать». Все настройки видно сразу."), 8)

        // главный выключатель
        val master = card()
        masterSwitch = Switch(this)
        masterSwitch.isChecked = sp.getBoolean(Prefs.K_ENABLED, true)
        masterSwitch.setOnCheckedChangeListener { _, checked ->
            sp.edit().putBoolean(Prefs.K_ENABLED, checked).apply()
            OverlayService.sync(this)
            updateUi()
        }
        master.addView(rowOf(label("Снегопад включён", "Главный выключатель для обоев и приложений"), masterSwitch))
        col.add(master, 16)

        // режим
        col.add(section("Где идёт снег"), 20)
        addMode(col, Prefs.MODE_WALLPAPER, "🖼  Только на обоях", "Рабочий стол и экран блокировки")
        addMode(col, Prefs.MODE_APPS, "📱  Только в приложениях", "Снег поверх любых приложений")
        addMode(col, Prefs.MODE_BOTH, "✨  И там, и там", "Максимум новогоднего настроения")

        overlayRow = permRow("Поверх других приложений", "Разрешить") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        wallpaperRow = permRow("Живые обои «Снегопад»", "Установить") { openWallpaperPicker() }
        col.add(overlayRow.root, 12)
        col.add(wallpaperRow.root, 8)

        // пресеты
        col.add(section("Быстрые пресеты"), 24)
        col.add(presetRow(), 8)

        // вид снега
        col.add(section("Вид снега"), 24)
        val look = card()
        look.add(titleView("Тип снежинок"), 0)
        look.add(
            chips(
                listOf("Смесь", "Пушистый", "Кристаллы", "Метель", "Звёздочки", "Огоньки"),
                Prefs.K_STYLE, 3
            ), 8
        )
        look.add(titleView("Цвет снега"), 16)
        look.add(
            chips(
                listOf("Белый", "Ледяной", "Золотой", "Розовый", "Мятный"),
                Prefs.K_COLOR, 0,
                intArrayOf(
                    Color.parseColor("#FFFFFF"), Color.parseColor("#BFE4FF"), Color.parseColor("#FFD66B"),
                    Color.parseColor("#FFB3D9"), Color.parseColor("#B6FFD8")
                )
            ), 8
        )
        look.add(slider("Количество", Prefs.K_DENSITY, 55) { "$it%" }, 16)
        look.add(slider("Скорость", Prefs.K_SPEED, 50) { "$it%" }, 14)
        look.add(slider("Размер хлопьев", Prefs.K_SIZE, 50) { "$it%" }, 14)
        look.add(slider("Ветер", Prefs.K_WIND, 40) { "$it%" }, 14)
        col.add(look, 8)

        // сугробы и эффекты
        col.add(section("Сугробы и эффекты"), 24)
        val fx = card()
        fx.add(switchRow("Сугробы", "Снег оседает внизу экрана", Prefs.K_DRIFTS, true), 0)
        fx.add(slider("Таяние сугробов", Prefs.K_MELT, 30) { if (it == 0) "не тают" else "$it%" }, 14)
        fx.add(slider("Морозное стекло", Prefs.K_FROST, 0) { if (it == 0) "выкл" else "$it%" }, 14)
        fx.add(switchRow("Ветер от наклона", "Снег сносит, когда наклоняешь телефон", Prefs.K_TILT, true), 14)
        fx.add(switchRow("Сметать касанием", "На живых обоях: проведи по снегу пальцем", Prefs.K_SWEEP, true), 14)
        col.add(fx, 8)

        // гирлянда
        col.add(section("Гирлянда"), 24)
        val gl = card()
        gl.add(switchRow("Гирлянда сверху", "Мерцающие огоньки по верху экрана", Prefs.K_GARLAND, true), 0)
        gl.add(titleView("Цвета"), 16)
        gl.add(
            chips(
                listOf("Классика", "Тёплая", "Холодная", "Красно-золотая", "Розово-сиреневая"),
                Prefs.K_GPAL, 0
            ), 8
        )
        gl.add(titleView("Режим свечения"), 16)
        gl.add(chips(listOf("Мерцание", "Дыхание", "Бегущие огни", "Горят ровно"), Prefs.K_GANIM, 0), 8)
        gl.add(slider("Размер лампочек", Prefs.K_GSIZE, 50) { "$it%" }, 16)
        gl.add(slider("Густота лампочек", Prefs.K_GDENS, 30) { "$it%" }, 14)
        gl.add(slider("Провисание провода", Prefs.K_GSAG, 40) { "$it%" }, 14)
        col.add(gl, 8)

        // обратный отсчёт
        col.add(section("До Нового года"), 24)
        val cd = card()
        cd.add(switchRow("Обратный отсчёт", "Надпись на живых обоях; с 1 по 7 января — поздравление", Prefs.K_COUNTDOWN, true), 0)
        cd.add(titleView("Где показывать"), 16)
        cd.add(chips(listOf("Под часами", "По центру", "Внизу"), Prefs.K_CDPOS, 2), 8)
        col.add(cd, 8)

        // фон обоев
        col.add(section("Фон живых обоев"), 24)
        val bg = card()
        bg.add(
            chips(
                listOf("Ночные горы", "Ёлка с подарками", "Северное сияние", "Своё фото"),
                Prefs.K_BG, 0, null
            ) { i ->
                if (i == Prefs.BG_CUSTOM && !File(filesDir, "bg.jpg").exists()) {
                    pickImage()
                    true
                } else {
                    false
                }
            }, 0
        )
        val pickBtn = smallButton("Выбрать другое фото…") { pickImage() }
        bg.add(pickBtn, 12)
        col.add(bg, 8)
        col.add(hint("Фон, метеоры и отсчёт видны на живых обоях. Поверх приложений рисуются только снег, гирлянда и мороз."), 8)

        // сброс и подсказка
        val reset = smallButton("Сбросить все настройки") {
            val keepMode = sp.getInt(Prefs.K_MODE, Prefs.MODE_BOTH)
            sp.edit().clear().putInt(Prefs.K_MODE, keepMode).apply()
            masterSwitch.isChecked = true
            OverlayService.sync(this)
            updateUi()
        }
        col.add(reset, 20)
        col.add(
            hint(
                "Если снег пропадает через время (Xiaomi, Huawei, Samsung, OnePlus), открой настройки " +
                    "приложения: разреши автозапуск, а ограничение батареи поставь «Без ограничений»."
            ), 16
        )

        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        sp.registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onResume() {
        super.onResume()
        preview.start()
        updateUi()
        OverlayService.sync(this)
    }

    override fun onPause() {
        preview.stop()
        super.onPause()
    }

    override fun onDestroy() {
        sp.unregisterOnSharedPreferenceChangeListener(prefsListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- состояние

    private fun updateUi() {
        val mode = sp.getInt(Prefs.K_MODE, Prefs.MODE_BOTH)
        for (i in modeCards.indices) {
            val sel = i == mode
            modeCards[i].background = roundBg(
                if (sel) Color.parseColor("#1B2B5C") else CARD, 18,
                if (sel) ACCENT else LINE, if (sel) 2 else 1
            )
        }

        val canOverlay = Settings.canDrawOverlays(this)
        overlayRow.root.visibility = if (mode != Prefs.MODE_WALLPAPER) View.VISIBLE else View.GONE
        overlayRow.status.text = if (canOverlay) "✓ Разрешение выдано" else "Нужно разрешение, чтобы снег шёл поверх приложений"
        overlayRow.status.setTextColor(if (canOverlay) GOOD else SUB)
        overlayRow.button.visibility = if (canOverlay) View.GONE else View.VISIBLE

        val wpActive = wallpaperActive()
        wallpaperRow.root.visibility = if (mode != Prefs.MODE_APPS) View.VISIBLE else View.GONE
        wallpaperRow.status.text = if (wpActive) "✓ Живые обои установлены" else "Установи живые обои, чтобы снег шёл на рабочем столе"
        wallpaperRow.status.setTextColor(if (wpActive) GOOD else SUB)
        wallpaperRow.button.visibility = if (wpActive) View.GONE else View.VISIBLE

        for (r in refreshers) r()
    }

    private fun wallpaperActive(): Boolean {
        val info = WallpaperManager.getInstance(this).wallpaperInfo
        return info != null && info.packageName == packageName
    }

    private fun openWallpaperPicker() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, SnowWallpaperService::class.java)
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Toast.makeText(this, "Открой «Обои» в настройках и выбери «Снегопад»", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------------------- свой фон

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть выбор фото", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            importBackground(uri)
        }
    }

    private fun importBackground(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options()
                bounds.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 3000) sample *= 2
                val opts = BitmapFactory.Options()
                opts.inSampleSize = sample
                val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) {
                    runOnUiThread { Toast.makeText(this, "Не удалось прочитать фото", Toast.LENGTH_SHORT).show() }
                    return@Thread
                }
                File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                bmp.recycle()
                runOnUiThread {
                    sp.edit()
                        .putInt(Prefs.K_BG, Prefs.BG_CUSTOM)
                        .putInt(Prefs.K_BG_REV, sp.getInt(Prefs.K_BG_REV, 0) + 1)
                        .apply()
                    updateUi()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    // ---------------------------------------------------------------- пресеты

    private fun applyPreset(density: Int, speed: Int, size: Int, wind: Int, style: Int, color: Int) {
        sp.edit()
            .putInt(Prefs.K_DENSITY, density)
            .putInt(Prefs.K_SPEED, speed)
            .putInt(Prefs.K_SIZE, size)
            .putInt(Prefs.K_WIND, wind)
            .putInt(Prefs.K_STYLE, style)
            .putInt(Prefs.K_COLOR, color)
            .apply()
        for (r in refreshers) r()
    }

    private fun presetRow(): View {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val items = listOf<Pair<String, () -> Unit>>(
            Pair("🌨 Лёгкий") { applyPreset(25, 35, 45, 20, 0, 0) },
            Pair("❄ Снегопад") { applyPreset(55, 50, 50, 40, 3, 0) },
            Pair("🌬 Метель") { applyPreset(90, 80, 40, 85, 2, 0) },
            Pair("✨ Волшебство") { applyPreset(60, 40, 60, 30, 4, 2) },
            Pair("🧊 Сказка") { applyPreset(45, 35, 75, 25, 1, 1) }
        )
        for (item in items) {
            val b = smallButton(item.first) { item.second() }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            row.addView(b, lp)
        }
        scroll.addView(row)
        return scroll
    }

    // ---------------------------------------------------------------- построение UI

    private fun LinearLayout.add(v: View, top: Int) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(top)
        addView(v, lp)
    }

    private fun roundBg(fill: Int, radius: Int, stroke: Int = 0, strokeDp: Int = 1): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(strokeDp), stroke)
        return d
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(CARD, 18, LINE)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun section(text: String): TextView {
        val t = TextView(this)
        t.text = text.uppercase()
        t.setTextColor(ACCENT)
        t.textSize = 12f
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.12f
        t.setPadding(dp(4), 0, 0, 0)
        return t
    }

    private fun titleView(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        return t
    }

    private fun hint(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(SUB)
        t.textSize = 12.5f
        t.setPadding(dp(4), 0, dp(4), 0)
        return t
    }

    private fun label(title: String, sub: String?): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(titleView(title))
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(SUB)
            s.textSize = 12.5f
            box.addView(s)
        }
        return box
    }

    private fun rowOf(left: View, right: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(right, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return r
    }

    private fun addMode(parent: LinearLayout, mode: Int, title: String, sub: String) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(label(title, sub))
        c.setOnClickListener {
            sp.edit().putInt(Prefs.K_MODE, mode).apply()
            OverlayService.sync(this)
            updateUi()
        }
        modeCards.add(c)
        parent.add(c, 8)
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.stateListAnimator = null
        b.setPadding(dp(14), dp(10), dp(14), dp(10))
        b.textSize = 14f
        b.setTextColor(Color.WHITE)
        b.background = roundBg(CHIP, 12)
        b.setOnClickListener { onClick() }
        return b
    }

    /** Ряд кнопок-вариантов с прокруткой; выбранный вариант хранится в настройках как число. */
    private fun chips(
        labels: List<String>,
        key: String,
        def: Int,
        colors: IntArray? = null,
        onPick: ((Int) -> Boolean)? = null
    ): View {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()

        fun paintAll() {
            val cur = sp.getInt(key, def)
            for (i in btns.indices) {
                val sel = i == cur
                val fill = if (colors != null) colors[i] else if (sel) ACCENT else CHIP
                btns[i].background = roundBg(fill, 12, if (sel) Color.WHITE else 0, 2)
                btns[i].setTextColor(if (colors != null || sel) INK else Color.WHITE)
            }
        }

        for (i in labels.indices) {
            val b = smallButton(labels[i]) {
                val consumed = onPick?.invoke(i) ?: false
                if (!consumed) sp.edit().putInt(key, i).apply()
                paintAll()
            }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            row.addView(b, lp)
        }
        paintAll()
        refreshers.add { paintAll() }
        scroll.addView(row)
        return scroll
    }

    private fun permRow(title: String, buttonText: String, onClick: () -> Unit): Row {
        val c = card()
        val s = TextView(this)
        s.setTextColor(SUB)
        s.textSize = 12.5f
        val b = smallButton(buttonText, onClick)
        b.background = roundBg(ACCENT, 12)
        b.setTextColor(INK)
        b.typeface = Typeface.DEFAULT_BOLD
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(titleView(title))
        left.addView(s)
        c.addView(rowOf(left, b))
        return Row(c, s, b)
    }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean): View {
        val sw = Switch(this)
        sw.isChecked = sp.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply() }
        refreshers.add { sw.isChecked = sp.getBoolean(key, def) }
        return rowOf(label(title, sub), sw)
    }

    private fun slider(title: String, key: String, def: Int, fmt: (Int) -> String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val value = TextView(this)
        value.setTextColor(ACCENT)
        value.textSize = 14f
        box.addView(rowOf(titleView(title), value))
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = sp.getInt(key, def)
        sb.progressTintList = ColorStateList.valueOf(ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(ACCENT)
        value.text = fmt(sb.progress)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                value.text = fmt(p)
                if (fromUser) sp.edit().putInt(key, p).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        refreshers.add {
            sb.progress = sp.getInt(key, def)
            value.text = fmt(sb.progress)
        }
        box.addView(sb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return box
    }
}
