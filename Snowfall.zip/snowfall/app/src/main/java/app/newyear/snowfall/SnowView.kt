package app.newyear.snowfall

import android.content.Context
import android.graphics.Canvas
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager

/** View со снегопадом. Для оверлея — без фона и касаний, для превью — с фоном и «сметанием». */
class SnowView(context: Context, private val withBackground: Boolean) :
    View(context), SensorEventListener {

    val scene = SnowScene(context, withBackground)

    private var last = 0L
    private var running = false
    private var sensorOn = false
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        scene.resize(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else (now - last) / 1_000_000_000f
        last = now
        scene.update(dt)
        scene.draw(canvas)
        if (running) postInvalidateOnAnimation()
    }

    fun start() {
        if (running) return
        running = true
        last = 0L
        updateSensor()
        invalidate()
    }

    fun stop() {
        running = false
        updateSensor()
    }

    fun reload() {
        scene.reload()
        updateSensor()
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!withBackground) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        scene.onTouch(e.actionMasked, e.x, e.y)
        return true
    }

    private fun updateSensor() {
        val want = running && scene.params.tilt
        if (want && !sensorOn) {
            val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) {
                sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
                sensorOn = true
            }
        } else if (!want && sensorOn) {
            sm.unregisterListener(this)
            sensorOn = false
            scene.tilt = 0f
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val v = e.values
        @Suppress("DEPRECATION")
        val rot = wm.defaultDisplay.rotation
        val g = when (rot) {
            Surface.ROTATION_90 -> v[1]
            Surface.ROTATION_180 -> v[0]
            Surface.ROTATION_270 -> -v[1]
            else -> -v[0]
        } / 9.81f
        scene.tilt += (g.coerceIn(-1f, 1f) - scene.tilt) * 0.08f
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
