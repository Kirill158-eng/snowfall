package app.newyear.snowfall

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import java.io.File
import kotlin.math.max
import kotlin.random.Random

/** Рисует фон для живых обоев: ночное небо, луна, заснеженные горы и ёлки (или своё фото). */
object Scenery {

    fun render(ctx: Context, w: Int, h: Int, custom: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (custom) {
            val f = File(ctx.filesDir, "bg.jpg")
            val src: Bitmap? = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (src != null) {
                val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
                val m = Matrix()
                m.postScale(scale, scale)
                m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
                c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
                c.drawColor(Color.argb(40, 0, 0, 20))
                src.recycle()
                return bmp
            }
        }
        night(c, w, h, ctx.resources.displayMetrics.density)
        return bmp
    }

    private fun col(hex: String) = Color.parseColor(hex)

    private fun ridge(rnd: Random, pts: Int, rough: Float): FloatArray {
        val a = FloatArray(pts + 1)
        a[0] = rnd.nextFloat()
        a[pts] = rnd.nextFloat()
        var step = pts
        var amp = 1f
        while (step > 1) {
            val half = step / 2
            var i = half
            while (i < pts) {
                a[i] = ((a[i - half] + a[i + half]) / 2f + (rnd.nextFloat() - 0.5f) * amp).coerceIn(0f, 1f)
                i += step
            }
            step = half
            amp *= rough
        }
        return a
    }

    private fun night(c: Canvas, w: Int, h: Int, dp: Float) {
        val rnd = Random(2026)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = w.toFloat()
        val hf = h.toFloat()

        // небо
        p.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(col("#040A22"), col("#0B1A4C"), col("#26437F"), col("#6A78B0")),
            floatArrayOf(0f, 0.4f, 0.72f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = null

        // звёзды
        for (i in 0 until 140) {
            p.color = Color.WHITE
            p.alpha = 60 + rnd.nextInt(160)
            c.drawCircle(rnd.nextFloat() * wf, rnd.nextFloat() * hf * 0.6f, (0.4f + rnd.nextFloat() * 1.1f) * dp, p)
        }

        // луна
        val mx = wf * 0.76f
        val my = hf * 0.13f
        val mr = wf * 0.05f
        p.shader = RadialGradient(
            mx, my, mr * 7f,
            intArrayOf(Color.argb(110, 170, 200, 255), Color.argb(0, 170, 200, 255)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(mx, my, mr * 7f, p)
        p.shader = null
        p.color = col("#F4F7FF")
        c.drawCircle(mx, my, mr, p)

        // горы
        mountain(c, w, h, rnd, 0.62f, 0.30f, 0.55f, "#D7E1FA", "#7482C0", "#2D3A78")
        mountain(c, w, h, rnd, 0.76f, 0.24f, 0.5f, "#9BAAE0", "#3C4A8C", "#171E4D")
        val hills = ridge(rnd, 128, 0.45f)
        val baseY = hf * 0.91f
        val range = hf * 0.07f
        val path = Path()
        path.moveTo(0f, hf)
        for (i in 0..128) path.lineTo(i * wf / 128f, baseY - hills[i] * range)
        path.lineTo(wf, hf)
        path.close()
        p.shader = LinearGradient(
            0f, baseY - range, 0f, hf,
            col("#2A3470"), col("#0B1034"), Shader.TileMode.CLAMP
        )
        c.drawPath(path, p)
        p.shader = null

        // ёлки
        val n = (wf / (20f * dp)).toInt()
        for (i in 0 until n) {
            val x = rnd.nextFloat() * wf
            val idx = (x / wf * 128f).toInt().coerceIn(0, 128)
            val gy = baseY - hills[idx] * range + 6f * dp
            val th = (34f + rnd.nextFloat() * 56f) * dp
            tree(c, p, x, gy, th)
        }
    }

    private fun mountain(
        c: Canvas, w: Int, h: Int, rnd: Random,
        baseFrac: Float, rangeFrac: Float, rough: Float,
        top: String, mid: String, bottom: String
    ) {
        val pts = 256
        val a = ridge(rnd, pts, rough)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val baseY = hf * baseFrac
        val range = hf * rangeFrac
        val path = Path()
        path.moveTo(0f, hf)
        for (i in 0..pts) path.lineTo(i * wf / pts, baseY - a[i] * range)
        path.lineTo(wf, hf)
        path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, baseY - range, 0f, baseY + hf * 0.12f,
            intArrayOf(col(top), col(mid), col(bottom)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(path, p)
    }

    private fun tree(c: Canvas, p: Paint, x: Float, baseY: Float, height: Float) {
        val tiers = 4
        val tierH = height / tiers * 1.5f
        for (t in 0 until tiers) {
            val topY = baseY - height + t * (height / tiers) * 0.8f
            val half = height * 0.17f * (0.45f + t * 0.3f)
            val path = Path()
            path.moveTo(x, topY)
            path.lineTo(x - half, topY + tierH)
            path.lineTo(x + half, topY + tierH)
            path.close()
            p.color = col("#080D2B")
            c.drawPath(path, p)
            // снежок на ветках
            val cap = Path()
            cap.moveTo(x, topY)
            cap.lineTo(x - half * 0.55f, topY + tierH * 0.5f)
            cap.lineTo(x + half * 0.55f, topY + tierH * 0.5f)
            cap.close()
            p.color = Color.argb(150, 143, 160, 214)
            c.drawPath(cap, p)
        }
    }
}
