package app.newyear.snowfall

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/** Рисует фоны для живых обоев: ночные горы, новогодняя ёлка, северное сияние или своё фото. */
object Scenery {

    fun render(ctx: Context, w: Int, h: Int, bg: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val dp = ctx.resources.displayMetrics.density
        if (bg == Prefs.BG_CUSTOM) {
            val f = File(ctx.filesDir, "bg.jpg")
            val src: Bitmap? = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (src != null) {
                val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
                val m = Matrix()
                m.postScale(scale, scale)
                m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
                c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
                c.drawColor(Color.argb(40, 0, 0, 20))
                src.recycle()
                return bmp
            }
        }
        when (bg) {
            Prefs.BG_TREE -> treeScene(c, w, h, dp)
            Prefs.BG_AURORA -> aurora(c, w, h, dp)
            else -> night(c, w, h, dp)
        }
        return bmp
    }

    private fun col(hex: String) = Color.parseColor(hex)

    private fun ridge(rnd: Random, pts: Int, rough: Float): FloatArray {
        val a = FloatArray(pts + 1)
        a[0] = rnd.nextFloat()
        a[pts] = rnd.nextFloat()
        var step = pts
        var amp = 1f
        while (step > 1) {
            val half = step / 2
            var i = half
            while (i < pts) {
                a[i] = ((a[i - half] + a[i + half]) / 2f + (rnd.nextFloat() - 0.5f) * amp).coerceIn(0f, 1f)
                i += step
            }
            step = half
            amp *= rough
        }
        return a
    }

    private fun stars(c: Canvas, w: Int, h: Int, rnd: Random, n: Int, frac: Float, dp: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until n) {
            p.color = Color.WHITE
            p.alpha = 60 + rnd.nextInt(160)
            c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h * frac, (0.4f + rnd.nextFloat() * 1.1f) * dp, p)
        }
    }

    private fun moon(c: Canvas, w: Int, h: Int, xf: Float, yf: Float, rf: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val mx = w * xf
        val my = h * yf
        val mr = w * rf
        p.shader = RadialGradient(
            mx, my, mr * 7f,
            intArrayOf(Color.argb(110, 170, 200, 255), Color.argb(0, 170, 200, 255)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(mx, my, mr * 7f, p)
        p.shader = null
        p.color = col("#F4F7FF")
        c.drawCircle(mx, my, mr, p)
    }

    private fun skyGradient(c: Canvas, w: Int, h: Int, colors: IntArray, pos: FloatArray) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), colors, pos, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    // ---------------------------------------------------------------- ночные горы

    private fun night(c: Canvas, w: Int, h: Int, dp: Float) {
        val rnd = Random(2026)
        skyGradient(
            c, w, h,
            intArrayOf(col("#040A22"), col("#0B1A4C"), col("#26437F"), col("#6A78B0")),
            floatArrayOf(0f, 0.4f, 0.72f, 1f)
        )
        stars(c, w, h, rnd, 140, 0.6f, dp)
        moon(c, w, h, 0.76f, 0.13f, 0.05f)
        mountain(c, w, h, rnd, 0.62f, 0.30f, 0.55f, "#D7E1FA", "#7482C0", "#2D3A78")
        mountain(c, w, h, rnd, 0.76f, 0.24f, 0.5f, "#9BAAE0", "#3C4A8C", "#171E4D")
        foothills(c, w, h, rnd, dp)
    }

    private fun foothills(c: Canvas, w: Int, h: Int, rnd: Random, dp: Float) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val hills = ridge(rnd, 128, 0.45f)
        val baseY = hf * 0.91f
        val range = hf * 0.07f
        val path = Path()
        path.moveTo(0f, hf)
        for (i in 0..128) path.lineTo(i * wf / 128f, baseY - hills[i] * range)
        path.lineTo(wf, hf)
        path.close()
        p.shader = LinearGradient(0f, baseY - range, 0f, hf, col("#2A3470"), col("#0B1034"), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
        val n = (wf / (20f * dp)).toInt()
        for (i in 0 until n) {
            val x = rnd.nextFloat() * wf
            val idx = (x / wf * 128f).toInt().coerceIn(0, 128)
            val gy = baseY - hills[idx] * range + 6f * dp
            val th = (34f + rnd.nextFloat() * 56f) * dp
            pine(c, p, x, gy, th)
        }
    }

    private fun mountain(
        c: Canvas, w: Int, h: Int, rnd: Random,
        baseFrac: Float, rangeFrac: Float, rough: Float,
        top: String, mid: String, bottom: String
    ) {
        val pts = 256
        val a = ridge(rnd, pts, rough)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val baseY = hf * baseFrac
        val range = hf * rangeFrac
        val path = Path()
        path.moveTo(0f, hf)
        for (i in 0..pts) path.lineTo(i * wf / pts, baseY - a[i] * range)
        path.lineTo(wf, hf)
        path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, baseY - range, 0f, baseY + hf * 0.12f,
            intArrayOf(col(top), col(mid), col(bottom)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(path, p)
    }

    private fun pine(c: Canvas, p: Paint, x: Float, baseY: Float, height: Float) {
        val tiers = 4
        val tierH = height / tiers * 1.5f
        for (t in 0 until tiers) {
            val topY = baseY - height + t * (height / tiers) * 0.8f
            val half = height * 0.17f * (0.45f + t * 0.3f)
            val path = Path()
            path.moveTo(x, topY)
            path.lineTo(x - half, topY + tierH)
            path.lineTo(x + half, topY + tierH)
            path.close()
            p.color = col("#080D2B")
            c.drawPath(path, p)
            val cap = Path()
            cap.moveTo(x, topY)
            cap.lineTo(x - half * 0.55f, topY + tierH * 0.5f)
            cap.lineTo(x + half * 0.55f, topY + tierH * 0.5f)
            cap.close()
            p.color = Color.argb(150, 143, 160, 214)
            c.drawPath(cap, p)
        }
    }

    // ---------------------------------------------------------------- новогодняя ёлка

    private fun treeScene(c: Canvas, w: Int, h: Int, dp: Float) {
        val rnd = Random(77)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        skyGradient(
            c, w, h,
            intArrayOf(col("#030816"), col("#0A1A3A"), col("#1E3A66")),
            floatArrayOf(0f, 0.6f, 1f)
        )
        stars(c, w, h, rnd, 110, 0.55f, dp)
        moon(c, w, h, 0.82f, 0.09f, 0.035f)

        val cx = wf / 2f
        val topY = hf * 0.20f
        val baseT = hf * 0.84f
        val maxHalf = wf * 0.38f
        val n = 7
        val span = baseT - topY

        // ствол
        p.color = col("#4A2E1E")
        c.drawRect(cx - wf * 0.035f, baseT - hf * 0.03f, cx + wf * 0.035f, hf * 0.92f, p)

        val apexes = FloatArray(n)
        val bottoms = FloatArray(n)
        val halves = FloatArray(n)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 3f * dp
        edge.strokeCap = Paint.Cap.ROUND
        val gold = Paint(Paint.ANTI_ALIAS_FLAG)
        gold.style = Paint.Style.STROKE
        gold.strokeWidth = 2.2f * dp
        gold.strokeCap = Paint.Cap.ROUND
        gold.color = Color.argb(220, 255, 214, 107)
        for (i in 0 until n) {
            val apex = topY + span * (i.toFloat() / n) * 0.85f
            val bottom = apex + span * 0.28f
            val half = maxHalf * (0.25f + 0.75f * (i + 1).toFloat() / n)
            apexes[i] = apex
            bottoms[i] = bottom
            halves[i] = half
            val path = Path()
            path.moveTo(cx, apex)
            path.lineTo(cx - half, bottom)
            path.quadTo(cx, bottom - span * 0.05f, cx + half, bottom)
            path.close()
            p.shader = LinearGradient(0f, apex, 0f, bottom, col("#2A8A63"), col("#0B3B2C"), Shader.TileMode.CLAMP)
            c.drawPath(path, p)
            p.shader = null

            // снег на краю лапы
            val bot = Path()
            bot.moveTo(cx - half, bottom)
            bot.quadTo(cx, bottom - span * 0.05f, cx + half, bottom)
            edge.color = Color.argb(230, 225, 236, 255)
            c.drawPath(bot, edge)

            // золотая гирлянда по ярусу
            val gl = Path()
            val gy = bottom - span * 0.045f
            gl.moveTo(cx - half * 0.82f, gy)
            gl.quadTo(cx, gy + span * 0.035f, cx + half * 0.82f, gy)
            c.drawPath(gl, gold)
        }

        // шарики
        val ballColors = intArrayOf(
            col("#FF4D5E"), col("#FFC93C"), col("#5CB8FF"), col("#C77DFF"), col("#FF8FC8")
        )
        for (k in 0 until 34) {
            val i = rnd.nextInt(n)
            val f = 0.35f + rnd.nextFloat() * 0.55f
            val y = apexes[i] + (bottoms[i] - apexes[i]) * f
            val halfAt = halves[i] * f * 0.78f
            val x = cx + (rnd.nextFloat() * 2f - 1f) * halfAt
            val r = (5f + rnd.nextFloat() * 4f) * dp
            p.color = ballColors[rnd.nextInt(ballColors.size)]
            c.drawCircle(x, y, r, p)
            p.color = Color.argb(150, 255, 255, 255)
            c.drawCircle(x - r * 0.3f, y - r * 0.3f, r * 0.28f, p)
        }

        // звезда на макушке
        val sx = cx
        val sy = topY - hf * 0.005f
        val sr = wf * 0.045f
        p.shader = RadialGradient(
            sx, sy, sr * 3.2f,
            intArrayOf(Color.argb(160, 255, 220, 120), Color.argb(0, 255, 220, 120)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(sx, sy, sr * 3.2f, p)
        p.shader = null
        val star = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) sr else sr * 0.45f
            val a = (-90.0 + 36.0 * i) * PI / 180.0
            val px = sx + r * cos(a).toFloat()
            val py = sy + r * sin(a).toFloat()
            if (i == 0) star.moveTo(px, py) else star.lineTo(px, py)
        }
        star.close()
        p.color = col("#FFD66B")
        c.drawPath(star, p)

        // сугробы
        val hills = ridge(rnd, 128, 0.45f)
        val baseY = hf * 0.89f
        val range = hf * 0.06f
        val hp = Path()
        hp.moveTo(0f, hf)
        for (i in 0..128) hp.lineTo(i * wf / 128f, baseY - hills[i] * range)
        hp.lineTo(wf, hf)
        hp.close()
        p.shader = LinearGradient(0f, baseY - range, 0f, hf, col("#EEF4FF"), col("#9FB4E6"), Shader.TileMode.CLAMP)
        c.drawPath(hp, p)
        p.shader = null

        // подарки
        val gy = hf * 0.925f
        val boxes = arrayOf(
            floatArrayOf(0.20f, 0.13f, 0.065f),
            floatArrayOf(0.34f, 0.09f, 0.05f),
            floatArrayOf(0.66f, 0.10f, 0.055f),
            floatArrayOf(0.80f, 0.14f, 0.07f)
        )
        val boxCols = arrayOf(col("#D63B4A"), col("#2F7FD6"), col("#2FAE72"), col("#8A4FD6"))
        for (b in boxes.indices) {
            val bx = wf * boxes[b][0]
            val bw = wf * boxes[b][1]
            val bh = hf * boxes[b][2]
            p.color = boxCols[b]
            c.drawRect(bx - bw / 2f, gy - bh, bx + bw / 2f, gy, p)
            p.color = col("#FFE08A")
            c.drawRect(bx - bw * 0.07f, gy - bh, bx + bw * 0.07f, gy, p)
            c.drawRect(bx - bw / 2f, gy - bh * 0.56f, bx + bw / 2f, gy - bh * 0.44f, p)
            c.drawCircle(bx - bw * 0.1f, gy - bh - 3f * dp, 4f * dp, p)
            c.drawCircle(bx + bw * 0.1f, gy - bh - 3f * dp, 4f * dp, p)
        }
    }

    // ---------------------------------------------------------------- северное сияние

    private fun aurora(c: Canvas, w: Int, h: Int, dp: Float) {
        val rnd = Random(404)
        val wf = w.toFloat()
        val hf = h.toFloat()
        skyGradient(
            c, w, h,
            intArrayOf(col("#010616"), col("#071A33"), col("#0E2B4A")),
            floatArrayOf(0f, 0.55f, 1f)
        )
        stars(c, w, h, rnd, 130, 0.6f, dp)
        val tones = arrayOf(intArrayOf(70, 255, 176), intArrayOf(61, 214, 232), intArrayOf(165, 107, 255))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val steps = 60
        for (b in 0 until 3) {
            val baseY = hf * (0.20f + b * 0.09f)
            val amp = hf * (0.05f + 0.02f * b)
            val ph = rnd.nextFloat() * 6.28f
            val thick = hf * (0.22f - b * 0.03f)
            val ys = FloatArray(steps + 1)
            for (i in 0..steps) {
                ys[i] = baseY + amp * sin(i * 0.18f + ph) + amp * 0.5f * sin(i * 0.41f + ph * 2f)
            }
            val path = Path()
            path.moveTo(0f, ys[0])
            for (i in 1..steps) path.lineTo(wf * i / steps, ys[i])
            for (i in steps downTo 0) {
                val t = thick * (0.7f + 0.3f * sin(i * 0.3f + ph))
                path.lineTo(wf * i / steps, ys[i] + t)
            }
            path.close()
            val t0 = tones[b]
            p.shader = LinearGradient(
                0f, baseY - amp, 0f, baseY + amp + thick,
                intArrayOf(Color.argb(0, t0[0], t0[1], t0[2]), Color.argb(170, t0[0], t0[1], t0[2]), Color.argb(0, t0[0], t0[1], t0[2])),
                floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP
            )
            c.drawPath(path, p)
            p.shader = null
            // вертикальные «лучи» занавеса
            p.strokeWidth = 1.5f * dp
            for (k in 0 until 70) {
                val i = rnd.nextInt(steps)
                val x = wf * i / steps
                p.color = Color.argb(14 + rnd.nextInt(22), t0[0], t0[1], t0[2])
                c.drawLine(x, ys[i], x, ys[i] + thick * (0.5f + rnd.nextFloat() * 0.5f), p)
            }
        }
        mountain(c, w, h, rnd, 0.74f, 0.2f, 0.5f, "#1B2A55", "#0C1736", "#050A22")
        foothills(c, w, h, rnd, dp)
    }
}
