package app.newyear.snowfall

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Вся логика и отрисовка: хлопья разных видов, ветер, сугробы, гирлянда,
 * мороз по краям, обратный отсчёт до Нового года и метеоры.
 * Используется оверлеем, живыми обоями и превью в приложении.
 */
class SnowScene(private val ctx: Context, private val withBackground: Boolean) {

    private class Flake {
        var x = 0f
        var y = 0f
        var z = 0f
        var phase = 0f
        var rot = 0f
        var vr = 0f
        var kx = 0f
        var ky = 0f
        var crystal = false
    }

    var params: SnowParams = Prefs.load(ctx)
    var snowOn = true
    var tilt = 0f

    private val dp = ctx.resources.displayMetrics.density
    private val rnd = Random(System.nanoTime())
    private val flakes = ArrayList<Flake>()
    private var w = 0
    private var h = 0
    private var time = 0f

    private var heights = FloatArray(0)
    private var tmp = FloatArray(0)
    private var colW = 1f
    private var maxH = 1f
    private var pileMax = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    private val softSprite = makeSoft(Color.WHITE)
    private val crystalSprite = makeCrystal()
    private val starSprite = makeStar()

    // цвета снега: белый, ледяной, золотой, розовый, мятный
    private val tintColors = intArrayOf(
        Color.WHITE, Color.parseColor("#BFE4FF"), Color.parseColor("#FFD66B"),
        Color.parseColor("#FFB3D9"), Color.parseColor("#B6FFD8")
    )
    private var tintIdx = -1
    private var tintFilter: PorterDuffColorFilter? = null

    // палитры гирлянды
    private val palettes: Array<IntArray> = arrayOf(
        intArrayOf(Color.parseColor("#FF4D5E"), Color.parseColor("#FFC93C"), Color.parseColor("#4DE38A"), Color.parseColor("#5CB8FF")),
        intArrayOf(Color.parseColor("#FFE2A8"), Color.parseColor("#FFD27A"), Color.parseColor("#FFEBC8")),
        intArrayOf(Color.parseColor("#BFE4FF"), Color.parseColor("#8EC9FF"), Color.parseColor("#E6F4FF")),
        intArrayOf(Color.parseColor("#FF4D5E"), Color.parseColor("#FFC93C")),
        intArrayOf(Color.parseColor("#FF6FB5"), Color.parseColor("#B78CFF"), Color.parseColor("#6FD8FF"))
    )
    private var gpalIdx = -1
    private var gColors = palettes[0]
    private var gSprites: List<Bitmap> = emptyList()
    private val confettiSprites = palettes[0].map { makeSoft(it) }

    private val driftPath = Path()
    private val driftFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val driftEdge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wirePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wirePath = Path()
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frostPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cdPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cdSubPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val meteorPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var scenery: Bitmap? = null
    private var sceneryKey = 0
    private var stars = FloatArray(0)

    private var cdKey = -1L
    private var cdLine1 = ""
    private var cdLine2 = ""

    private var meteorTimer = 4f
    private var mLife = 0f
    private var mx = 0f
    private var my = 0f
    private var mvx = 0f
    private var mvy = 0f

    private var lx = 0f
    private var ly = 0f

    init {
        driftEdge.style = Paint.Style.STROKE
        driftEdge.strokeWidth = 2.5f * dp
        driftEdge.color = Color.argb(150, 255, 255, 255)
        wirePaint.style = Paint.Style.STROKE
        wirePaint.strokeWidth = 1.6f * dp
        wirePaint.color = Color.parseColor("#0F3D2E")
        cdPaint.textAlign = Paint.Align.CENTER
        cdPaint.textSize = 30f * dp
        cdPaint.typeface = Typeface.DEFAULT_BOLD
        cdPaint.color = Color.WHITE
        cdPaint.setShadowLayer(8f * dp, 0f, 2f * dp, Color.argb(170, 0, 0, 30))
        cdSubPaint.textAlign = Paint.Align.CENTER
        cdSubPaint.textSize = 13f * dp
        cdSubPaint.letterSpacing = 0.15f
        cdSubPaint.color = Color.parseColor("#D5E2FF")
        cdSubPaint.setShadowLayer(6f * dp, 0f, 1f * dp, Color.argb(170, 0, 0, 30))
        meteorPaint.strokeWidth = 2f * dp
        meteorPaint.strokeCap = Paint.Cap.ROUND
    }

    fun reload() {
        params = Prefs.load(ctx)
    }

    fun resize(nw: Int, nh: Int) {
        if (nw <= 0 || nh <= 0) return
        w = nw
        h = nh
        colW = 6f * dp
        val n = (w / colW).toInt() + 3
        heights = FloatArray(n)
        tmp = FloatArray(n)
        maxH = h * 0.055f
        pileMax = 0f
        driftFill.shader = LinearGradient(
            0f, h - maxH, 0f, h.toFloat(),
            Color.WHITE, Color.parseColor("#C5D5F4"), Shader.TileMode.CLAMP
        )
        val rim = Color.argb(0, 205, 230, 255)
        frostPaint.shader = RadialGradient(
            w / 2f, h / 2f, sqrt((w * w + h * h).toFloat()) / 2f,
            intArrayOf(rim, rim, Color.argb(255, 205, 230, 255)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        stars = FloatArray(36 * 3)
        for (i in 0 until 36) {
            stars[i * 3] = rnd.nextFloat() * w
            stars[i * 3 + 1] = rnd.nextFloat() * h * 0.5f
            stars[i * 3 + 2] = rnd.nextFloat() * 6.28f
        }
        flakes.clear()
        repeat(targetCount()) { flakes.add(newFlake(true)) }
        scenery = null
    }

    private fun targetCount(): Int {
        if (params.density <= 0 || w == 0) return 0
        val area = ((w.toFloat() * h) / (1080f * 2400f)).coerceIn(0.25f, 2f)
        val styleMul = if (params.style == 2) 1.5f else 1f
        return max(12, (params.density / 100f * 450f * area * styleMul).toInt())
    }

    private fun newFlake(anywhere: Boolean): Flake {
        val f = Flake()
        f.x = rnd.nextFloat() * w
        f.y = if (anywhere) rnd.nextFloat() * h else -(20f + rnd.nextFloat() * 60f) * dp
        f.z = rnd.nextFloat()
        f.phase = rnd.nextFloat() * 6.28f
        f.rot = rnd.nextFloat() * 360f
        f.vr = (rnd.nextFloat() - 0.5f) * 70f
        f.crystal = rnd.nextFloat() < 0.14f
        return f
    }

    // ------------------------------------------------------------------ физика

    fun update(rawDt: Float) {
        if (w == 0 || !snowOn) return
        val dt = rawDt.coerceIn(0.001f, 0.05f)
        time += dt

        val st = params.style
        val speedMul = if (st == 2) 1.5f else 1f
        val windMul = if (st == 2) 2.2f else 1f

        val target = targetCount()
        if (flakes.size < target) {
            repeat(min(target - flakes.size, 4)) { flakes.add(newFlake(false)) }
        }

        val gust = (sin(time * 0.37f) + sin(time * 0.13f + 1.7f) * 0.7f + sin(time * 1.1f) * 0.2f) / 1.9f
        val windV = gust * (params.wind / 100f) * 60f * dp * windMul + tilt * 220f * dp
        val speedScale = (0.3f + params.speed / 100f * 1.4f) * speedMul
        val damp = 1f - 2.2f * dt
        val edge = 40f * dp

        var i = 0
        while (i < flakes.size) {
            val f = flakes[i]
            val depth = 0.35f + 0.65f * f.z
            val vy = (26f + 60f * f.z) * dp * speedScale
            val vx = windV * depth + sin(time * 0.9f + f.phase) * 12f * dp * depth + f.kx
            f.x += vx * dt
            f.y += (vy + f.ky) * dt
            f.kx *= damp
            f.ky *= damp
            f.rot += f.vr * dt
            if (f.x < -edge) f.x = w + edge else if (f.x > w + edge) f.x = -edge

            val ground = if (params.drifts) h - heightAt(f.x) else h + 20f * dp
            if (f.y >= ground) {
                if (params.drifts && f.z > 0.25f) addSnow(f.x, f.z)
                if (flakes.size > target) {
                    flakes[i] = flakes[flakes.size - 1]
                    flakes.removeAt(flakes.size - 1)
                    continue
                }
                f.x = rnd.nextFloat() * w
                f.y = -(20f + rnd.nextFloat() * 60f) * dp
                f.z = rnd.nextFloat()
                f.kx = 0f
                f.ky = 0f
            }
            i++
        }

        if (params.drifts) updatePile(dt) else if (pileMax > 0f) {
            java.util.Arrays.fill(heights, 0f)
            pileMax = 0f
        }

        if (withBackground && !params.customBg) updateMeteor(dt)
    }

    private fun updateMeteor(dt: Float) {
        if (mLife > 0f) {
            mx += mvx * dt
            my += mvy * dt
            mLife -= dt
        } else {
            meteorTimer -= dt
            if (meteorTimer <= 0f) {
                mx = rnd.nextFloat() * w * 0.7f
                my = rnd.nextFloat() * h * 0.25f
                mvx = (420f + rnd.nextFloat() * 260f) * dp
                mvy = (170f + rnd.nextFloat() * 120f) * dp
                mLife = 0.9f
                meteorTimer = 6f + rnd.nextFloat() * 10f
            }
        }
    }

    private fun heightAt(x: Float): Float =
        heights[(x / colW).toInt().coerceIn(0, heights.size - 1)]

    private fun addSnow(x: Float, z: Float) {
        val idx = (x / colW).toInt().coerceIn(0, heights.size - 1)
        val amt = (0.5f + z) * dp * 0.9f
        heights[idx] += amt * 0.5f
        if (idx > 0) heights[idx - 1] += amt * 0.25f
        if (idx < heights.size - 1) heights[idx + 1] += amt * 0.25f
    }

    private fun updatePile(dt: Float) {
        val n = heights.size
        val melt = params.melt / 100f * 0.5f * dp * dt
        val maxDiff = 1.6f * dp
        for (pass in 0 until 2) {
            for (c in 0 until n - 1) {
                val d = heights[c] - heights[c + 1]
                if (abs(d) > maxDiff) {
                    val m = (abs(d) - maxDiff) * 0.25f * (if (d > 0f) 1f else -1f)
                    heights[c] -= m
                    heights[c + 1] += m
                }
            }
        }
        tmp[0] = heights[0]
        tmp[n - 1] = heights[n - 1]
        for (c in 1 until n - 1) {
            tmp[c] = heights[c] * 0.7f + (heights[c - 1] + heights[c + 1]) * 0.15f
        }
        var mxh = 0f
        for (c in 0 until n) {
            val v = (tmp[c] - melt).coerceIn(0f, maxH)
            heights[c] = v
            if (v > mxh) mxh = v
        }
        pileMax = mxh
    }

    // ------------------------------------------------------------------ «сметание»

    fun onTouch(action: Int, x: Float, y: Float) {
        if (!params.sweep || !snowOn || w == 0) return
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                lx = x
                ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                sweep(x, y, x - lx, y - ly)
                lx = x
                ly = y
            }
        }
    }

    private fun sweep(x: Float, y: Float, dx: Float, dy: Float) {
        val r = 70f * dp
        val r2 = r * r
        for (f in flakes) {
            val ox = f.x - x
            val oy = f.y - y
            val d2 = ox * ox + oy * oy
            if (d2 < r2 && d2 > 1f) {
                val d = sqrt(d2)
                val k = 1f - d / r
                f.kx += (ox / d * 120f * dp + dx * 14f) * k
                f.ky += (oy / d * 120f * dp + dy * 14f) * k
            }
        }
        if (!params.drifts || y < h - maxH - r) return
        val c0 = ((x - r) / colW).toInt().coerceAtLeast(0)
        val c1 = ((x + r) / colW).toInt().coerceAtMost(heights.size - 1)
        var removed = 0f
        for (c in c0..c1) {
            val cx = (c + 0.5f) * colW
            val k = 1f - abs(cx - x) / r
            if (k <= 0f) continue
            if (y > h - heights[c] - 25f * dp) {
                val cut = heights[c] * 0.3f * k
                heights[c] -= cut
                removed += cut
            }
        }
        if (removed > 0.2f) {
            val dir = if (dx >= 0f) 1f else -1f
            val ec = ((x + dir * r * 1.15f) / colW).toInt().coerceIn(0, heights.size - 1)
            heights[ec] += removed * 0.5f
            if (flakes.size < targetCount() + 120) {
                val n = min(6, (removed / (0.4f * dp)).toInt() + 1)
                repeat(n) {
                    val sx = x + (rnd.nextFloat() - 0.5f) * r
                    spray(sx, h - heightAt(sx) - 6f * dp, dx)
                }
            }
        }
    }

    private fun spray(x: Float, y: Float, dx: Float) {
        val f = newFlake(false)
        f.x = x
        f.y = y
        f.z = 0.55f + rnd.nextFloat() * 0.45f
        f.crystal = false
        f.kx = dx * 12f + (rnd.nextFloat() - 0.5f) * 160f * dp
        f.ky = -(70f + rnd.nextFloat() * 160f) * dp
        flakes.add(f)
    }

    // ------------------------------------------------------------------ рисование

    fun draw(c: Canvas) {
        if (w == 0) return
        if (params.color != tintIdx) {
            tintIdx = params.color
            tintFilter = if (tintIdx <= 0 || tintIdx >= tintColors.size) null
            else PorterDuffColorFilter(tintColors[tintIdx], PorterDuff.Mode.SRC_IN)
        }
        if (withBackground) {
            drawScenery(c)
            if (params.countdown) drawCountdown(c)
        }
        if (!snowOn) return
        if (params.frost > 0) {
            frostPaint.alpha = (params.frost / 100f * 0.6f * 255f).toInt()
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), frostPaint)
        }
        val sizeScale = 0.55f + params.size / 100f * 0.9f
        drawFlakes(c, sizeScale, false)
        if (params.drifts && pileMax > 0.8f * dp) drawDrifts(c)
        drawFlakes(c, sizeScale, true)
        if (params.garland) drawGarland(c)
    }

    private fun drawScenery(c: Canvas) {
        val key = params.bg * 7919 + (if (params.customBg) params.bgRev + 1 else 0) * 1000003 + w * 31 + h
        if (scenery == null || key != sceneryKey) {
            scenery = Scenery.render(ctx, w, h, params.bg)
            sceneryKey = key
        }
        scenery?.let { c.drawBitmap(it, 0f, 0f, null) }
        if (params.bg == Prefs.BG_CUSTOM) return
        paint.colorFilter = null
        for (i in 0 until stars.size / 3) {
            val a = 0.3f + 0.7f * (0.5f + 0.5f * sin(time * 1.6f + stars[i * 3 + 2]))
            paint.alpha = (a * 255f).toInt()
            val s = 5f * dp
            dst.set(stars[i * 3] - s, stars[i * 3 + 1] - s, stars[i * 3] + s, stars[i * 3 + 1] + s)
            c.drawBitmap(softSprite, null, dst, paint)
        }
        if (mLife > 0f) {
            val a = (mLife / 0.9f).coerceIn(0f, 1f)
            meteorPaint.color = Color.argb((a * 230f).toInt(), 255, 255, 255)
            c.drawLine(mx, my, mx - mvx * 0.14f, my - mvy * 0.14f, meteorPaint)
        }
    }

    private fun drawSprite(c: Canvas, bmp: Bitmap, x: Float, y: Float, s: Float, rot: Float) {
        if (rot != 0f) {
            c.save()
            c.rotate(rot, x, y)
            dst.set(x - s, y - s, x + s, y + s)
            c.drawBitmap(bmp, null, dst, paint)
            c.restore()
        } else {
            dst.set(x - s, y - s, x + s, y + s)
            c.drawBitmap(bmp, null, dst, paint)
        }
    }

    private fun drawFlakes(c: Canvas, scale: Float, near: Boolean) {
        val st = params.style
        val sizeMul = when (st) {
            0 -> 1.15f
            2 -> 0.6f
            else -> 1f
        }
        paint.colorFilter = if (st == 5) null else tintFilter
        for (f in flakes) {
            if ((f.z >= 0.5f) != near) continue
            val base = (2.6f + 4.6f * f.z) * dp * scale * sizeMul
            val a = (0.35f + 0.65f * f.z) * 255f
            paint.alpha = a.toInt()
            when (st) {
                1 -> if (f.z > 0.4f) {
                    drawSprite(c, crystalSprite, f.x, f.y, base * 2.8f, f.rot)
                } else {
                    drawSprite(c, softSprite, f.x, f.y, base * 1.6f, 0f)
                }
                3 -> if (f.crystal && f.z > 0.55f) {
                    drawSprite(c, crystalSprite, f.x, f.y, base * 2.6f, f.rot)
                } else {
                    drawSprite(c, softSprite, f.x, f.y, base * 1.6f, 0f)
                }
                4 -> {
                    val tw = 0.55f + 0.45f * sin(time * 3f + f.phase * 3f)
                    paint.alpha = (a * tw).toInt()
                    drawSprite(c, starSprite, f.x, f.y, base * 2.4f, f.rot * 0.3f)
                }
                5 -> {
                    val idx = (f.phase * 10f).toInt() % confettiSprites.size
                    drawSprite(c, confettiSprites[idx], f.x, f.y, base * 1.35f, 0f)
                }
                else -> drawSprite(c, softSprite, f.x, f.y, base * 1.6f, 0f)
            }
        }
        paint.colorFilter = null
    }

    private fun drawDrifts(c: Canvas) {
        val n = heights.size
        val hf = h.toFloat()
        driftPath.rewind()
        driftPath.moveTo(0f, hf)
        driftPath.lineTo(0f, hf - heights[0])
        for (i in 0 until n - 1) {
            val cx = (i + 0.5f) * colW
            val cy = hf - heights[i]
            val nx = (i + 1.5f) * colW
            val ny = hf - heights[i + 1]
            driftPath.quadTo(cx, cy, (cx + nx) / 2f, (cy + ny) / 2f)
        }
        driftPath.lineTo(w.toFloat(), hf - heights[n - 1])
        driftPath.lineTo(w.toFloat(), hf)
        driftPath.close()
        driftFill.alpha = 245
        c.drawPath(driftPath, driftFill)
        c.drawPath(driftPath, driftEdge)

        paint.colorFilter = null
        for (i in 0 until 14) {
            val col = (i * 37 + 11) % n
            if (heights[col] < 3f * dp) continue
            val a = 0.5f + 0.5f * sin(time * 2.3f + i * 1.7f)
            paint.alpha = (a * 220f).toInt()
            val gx = col * colW
            val gy = hf - heights[col] + (i % 3) * 4f * dp
            drawSprite(c, softSprite, gx, gy, 4f * dp, 0f)
        }
    }

    private fun drawGarland(c: Canvas) {
        if (params.gpal != gpalIdx) {
            gpalIdx = params.gpal
            gColors = palettes[gpalIdx.coerceIn(0, palettes.size - 1)]
            gSprites = gColors.map { makeSoft(it) }
        }
        val arcs = max(3, (w / (130f * dp)).toInt())
        val seg = w.toFloat() / arcs
        val sag = (12f + 40f * params.gsag / 100f) * dp
        val y0 = 2f * dp
        wirePath.rewind()
        for (k in 0 until arcs) {
            wirePath.moveTo(k * seg, y0)
            wirePath.quadTo(k * seg + seg / 2f, y0 + 2f * sag, (k + 1) * seg, y0)
        }
        c.drawPath(wirePath, wirePaint)

        val per = 3 + (params.gdens / 100f * 7f).toInt()
        val s = (6f + 10f * params.gsize / 100f) * dp
        paint.colorFilter = null
        for (k in 0 until arcs) {
            for (j in 0 until per) {
                val t = (j + 0.5f) / per
                val bx = k * seg + t * seg
                val by = y0 + 4f * sag * t * (1f - t) + 3f * dp
                val gi = k * per + j
                val idx = gi % gColors.size
                val a: Float = when (params.ganim) {
                    0 -> 0.55f + 0.45f * sin(time * 2.4f + gi * 1.3f)
                    1 -> 0.5f + 0.5f * sin(time * 1.5f)
                    2 -> {
                        val q = 0.5f + 0.5f * sin(time * 6f - gi * 1.2f)
                        0.25f + 0.75f * q * q * q
                    }
                    else -> 1f
                }
                val aa = a.coerceIn(0.05f, 1f)
                paint.alpha = (aa * 255f).toInt()
                drawSprite(c, gSprites[idx], bx, by, s, 0f)
                corePaint.color = gColors[idx]
                corePaint.alpha = (120 + aa * 135f).toInt()
                c.drawCircle(bx, by, s * 0.27f, corePaint)
            }
        }
    }

    private fun drawCountdown(c: Canvas) {
        val nowSec = System.currentTimeMillis() / 1000L
        if (nowSec != cdKey) {
            cdKey = nowSec
            computeCountdown()
        }
        val y = when (params.cdpos) {
            0 -> h * 0.30f
            1 -> h * 0.50f
            else -> h * 0.78f
        }
        c.drawText(cdLine1, w / 2f, y, cdSubPaint)
        c.drawText(cdLine2, w / 2f, y + 36f * dp, cdPaint)
    }

    private fun computeCountdown() {
        val now = Calendar.getInstance()
        val year = now.get(Calendar.YEAR)
        if (now.get(Calendar.MONTH) == Calendar.JANUARY && now.get(Calendar.DAY_OF_MONTH) <= 7) {
            cdLine1 = "С НОВЫМ ГОДОМ!"
            cdLine2 = year.toString()
            return
        }
        val target = Calendar.getInstance()
        target.set(year + 1, Calendar.JANUARY, 1, 0, 0, 0)
        target.set(Calendar.MILLISECOND, 0)
        val ms = max(0L, target.timeInMillis - now.timeInMillis)
        val days = ms / 86_400_000L
        val rem = ms % 86_400_000L
        val hh = rem / 3_600_000L
        val mm = (rem % 3_600_000L) / 60_000L
        val ss = (rem % 60_000L) / 1000L
        cdLine1 = "ДО НОВОГО ГОДА"
        cdLine2 = String.format(Locale.US, "%d дн %02d:%02d:%02d", days, hh, mm, ss)
    }

    // ------------------------------------------------------------------ спрайты

    private fun makeSoft(color: Int): Bitmap {
        val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        p.shader = RadialGradient(
            32f, 32f, 32f,
            intArrayOf(
                Color.argb(255, r, g, b), Color.argb(225, r, g, b),
                Color.argb(85, r, g, b), Color.argb(0, r, g, b)
            ),
            floatArrayOf(0f, 0.25f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(32f, 32f, 32f, p)
        return bmp
    }

    private fun makeCrystal(): Bitmap {
        val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (pass in 0 until 2) {
            p.color = Color.WHITE
            p.strokeWidth = if (pass == 0) 10f else 4f
            p.alpha = if (pass == 0) 70 else 255
            for (i in 0 until 6) {
                c.save()
                c.rotate(i * 60f, 64f, 64f)
                c.drawLine(64f, 64f, 64f, 8f, p)
                c.drawLine(64f, 28f, 53f, 16f, p)
                c.drawLine(64f, 28f, 75f, 16f, p)
                c.drawLine(64f, 44f, 56f, 36f, p)
                c.drawLine(64f, 44f, 72f, 36f, p)
                c.restore()
            }
        }
        return bmp
    }

    /** Четырёхлучевая искорка со свечением. */
    private fun makeStar(): Bitmap {
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            48f, 48f, 30f,
            intArrayOf(Color.argb(200, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(48f, 48f, 30f, p)
        p.shader = null
        p.color = Color.WHITE
        val path = Path()
        path.moveTo(48f, 3f)
        path.lineTo(54f, 42f)
        path.lineTo(93f, 48f)
        path.lineTo(54f, 54f)
        path.lineTo(48f, 93f)
        path.lineTo(42f, 54f)
        path.lineTo(3f, 48f)
        path.lineTo(42f, 42f)
        path.close()
        c.drawPath(path, p)
        return bmp
    }
}
