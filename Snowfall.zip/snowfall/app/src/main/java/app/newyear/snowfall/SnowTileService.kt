package app.newyear.snowfall

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка в шторке: быстро включить или выключить снег. */
class SnowTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val sp = Prefs.sp(this)
        val on = !sp.getBoolean(Prefs.K_ENABLED, true)
        sp.edit().putBoolean(Prefs.K_ENABLED, on).apply()
        if (on) OverlayService.sync(this)
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = Prefs.sp(this).getBoolean(Prefs.K_ENABLED, true)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Снегопад"
        t.updateTile()
    }
}
