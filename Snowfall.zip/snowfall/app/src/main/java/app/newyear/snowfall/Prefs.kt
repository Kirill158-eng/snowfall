package app.newyear.snowfall

import android.content.Context
import android.content.SharedPreferences

class SnowParams(
    val enabled: Boolean,
    val mode: Int,
    val density: Int,
    val speed: Int,
    val size: Int,
    val wind: Int,
    val melt: Int,
    val drifts: Boolean,
    val tilt: Boolean,
    val garland: Boolean,
    val crystals: Boolean,
    val sweep: Boolean,
    val customBg: Boolean,
    val bgRev: Int
)

object Prefs {
    const val FILE = "snow_prefs"

    const val MODE_WALLPAPER = 0
    const val MODE_APPS = 1
    const val MODE_BOTH = 2

    const val K_ENABLED = "enabled"
    const val K_MODE = "mode"
    const val K_DENSITY = "density"
    const val K_SPEED = "speed"
    const val K_SIZE = "size"
    const val K_WIND = "wind"
    const val K_MELT = "melt"
    const val K_DRIFTS = "drifts"
    const val K_TILT = "tilt"
    const val K_GARLAND = "garland"
    const val K_CRYSTALS = "crystals"
    const val K_SWEEP = "sweep"
    const val K_BG = "bg"
    const val K_BG_REV = "bg_rev"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun overlayWanted(c: Context): Boolean {
        val s = sp(c)
        return s.getBoolean(K_ENABLED, true) && s.getInt(K_MODE, MODE_BOTH) != MODE_WALLPAPER
    }

    fun load(c: Context): SnowParams {
        val s = sp(c)
        return SnowParams(
            enabled = s.getBoolean(K_ENABLED, true),
            mode = s.getInt(K_MODE, MODE_BOTH),
            density = s.getInt(K_DENSITY, 55),
            speed = s.getInt(K_SPEED, 50),
            size = s.getInt(K_SIZE, 50),
            wind = s.getInt(K_WIND, 40),
            melt = s.getInt(K_MELT, 30),
            drifts = s.getBoolean(K_DRIFTS, true),
            tilt = s.getBoolean(K_TILT, true),
            garland = s.getBoolean(K_GARLAND, true),
            crystals = s.getBoolean(K_CRYSTALS, true),
            sweep = s.getBoolean(K_SWEEP, true),
            customBg = s.getInt(K_BG, 0) == 1,
            bgRev = s.getInt(K_BG_REV, 0)
        )
    }
}
