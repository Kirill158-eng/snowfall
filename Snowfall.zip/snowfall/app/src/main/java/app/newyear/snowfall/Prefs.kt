package app.newyear.snowfall

import android.content.Context
import android.content.SharedPreferences

class SnowParams(
    val enabled: Boolean,
    val mode: Int,
    val density: Int,
    val speed: Int,
    val size: Int,
    val wind: Int,
    val melt: Int,
    val drifts: Boolean,
    val tilt: Boolean,
    val sweep: Boolean,
    val style: Int,
    val color: Int,
    val frost: Int,
    val garland: Boolean,
    val gpal: Int,
    val ganim: Int,
    val gsize: Int,
    val gdens: Int,
    val gsag: Int,
    val countdown: Boolean,
    val cdpos: Int,
    val bg: Int,
    val bgRev: Int
) {
    val customBg: Boolean get() = bg == Prefs.BG_CUSTOM
}

object Prefs {
    const val FILE = "snow_prefs"

    const val MODE_WALLPAPER = 0
    const val MODE_APPS = 1
    const val MODE_BOTH = 2

    const val BG_MOUNTAINS = 0
    const val BG_TREE = 1
    const val BG_AURORA = 2
    const val BG_CUSTOM = 3

    const val K_ENABLED = "enabled"
    const val K_MODE = "mode"
    const val K_DENSITY = "density"
    const val K_SPEED = "speed"
    const val K_SIZE = "size"
    const val K_WIND = "wind"
    const val K_MELT = "melt"
    const val K_DRIFTS = "drifts"
    const val K_TILT = "tilt"
    const val K_SWEEP = "sweep"
    const val K_STYLE = "style"
    const val K_COLOR = "color"
    const val K_FROST = "frost"
    const val K_GARLAND = "garland"
    const val K_GPAL = "gpal"
    const val K_GANIM = "ganim"
    const val K_GSIZE = "gsize"
    const val K_GDENS = "gdens"
    const val K_GSAG = "gsag"
    const val K_COUNTDOWN = "countdown"
    const val K_CDPOS = "cdpos"
    const val K_BG = "bg"
    const val K_BG_REV = "bg_rev"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun overlayWanted(c: Context): Boolean {
        val s = sp(c)
        return s.getBoolean(K_ENABLED, true) && s.getInt(K_MODE, MODE_BOTH) != MODE_WALLPAPER
    }

    fun load(c: Context): SnowParams {
        val s = sp(c)
        return SnowParams(
            enabled = s.getBoolean(K_ENABLED, true),
            mode = s.getInt(K_MODE, MODE_BOTH),
            density = s.getInt(K_DENSITY, 55),
            speed = s.getInt(K_SPEED, 50),
            size = s.getInt(K_SIZE, 50),
            wind = s.getInt(K_WIND, 40),
            melt = s.getInt(K_MELT, 30),
            drifts = s.getBoolean(K_DRIFTS, true),
            tilt = s.getBoolean(K_TILT, true),
            sweep = s.getBoolean(K_SWEEP, true),
            style = s.getInt(K_STYLE, 3),
            color = s.getInt(K_COLOR, 0),
            frost = s.getInt(K_FROST, 0),
            garland = s.getBoolean(K_GARLAND, true),
            gpal = s.getInt(K_GPAL, 0),
            ganim = s.getInt(K_GANIM, 0),
            gsize = s.getInt(K_GSIZE, 50),
            gdens = s.getInt(K_GDENS, 30),
            gsag = s.getInt(K_GSAG, 40),
            countdown = s.getBoolean(K_COUNTDOWN, true),
            cdpos = s.getInt(K_CDPOS, 2),
            bg = s.getInt(K_BG, 0),
            bgRev = s.getInt(K_BG_REV, 0)
        )
    }
}
